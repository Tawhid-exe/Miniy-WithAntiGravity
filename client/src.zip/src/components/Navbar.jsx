import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingCart, Home, Package } from 'lucide-react';
import { useCart } from '../context/CartContext';
import ThemeToggle from './ThemeToggle';

function Navbar() {
    const location = useLocation();
    const { getCartCount } = useCart();

    const navItems = [
        { path: '/', icon: Home, label: 'Home' },
        { path: '/products', icon: Package, label: 'Products' },
        { path: '/cart', icon: ShoppingCart, label: 'Cart', badge: getCartCount() }
    ];

    return (
        <motion.nav
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className="fixed top-0 left-0 right-0 z-50 glass"
        >
            <div className="max-w-7xl mx-auto px-4 py-4">
                <div className="flex items-center justify-between">
                    {/* Logo */}
                    <Link to="/" className="text-2xl font-bold text-gradient">
                        FutureShop
                    </Link>

                    {/* Navigation Links + Theme Toggle */}
                    <div className="flex items-center gap-4">
                        {navItems.map((item) => {
                            const Icon = item.icon;
                            const isActive = location.pathname === item.path;

                            return (
                                <Link
                                    key={item.path}
                                    to={item.path}
                                    className="relative"
                                >
                                    <motion.div
                                        whileHover={{ scale: 1.1 }}
                                        whileTap={{ scale: 0.95 }}
                                        className={`
                                            flex items-center gap-2 px-4 py-2 rounded-full transition-all
                                            ${isActive
                                                ? 'bg-gradient-to-r from-primary to-secondary !text-white'
                                                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                                            }
                                        `}
                                    >
                                        <Icon size={20} />
                                        <span className="hidden sm:inline font-medium">{item.label}</span>
                                        {item.badge > 0 && (
                                            <motion.span
                                                initial={{ scale: 0 }}
                                                animate={{ scale: 1 }}
                                                className="absolute -top-2 -right-2 bg-secondary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold shadow-md"
                                            >
                                                {item.badge}
                                            </motion.span>
                                        )}
                                    </motion.div>
                                </Link>
                            );
                        })}

                        {/* Animated Theme Toggle */}
                        <ThemeToggle />
                    </div>
                </div>
            </div>
        </motion.nav>
    );
}

export default Navbar;
